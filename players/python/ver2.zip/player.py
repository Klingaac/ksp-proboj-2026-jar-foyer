#!/bin/env python
import sys
from typing import List
from data import World, Move, Person, World, Map, Shade, Tombstone, Point
from game import Game, PlayerInterface
from random import shuffle
import math

# // C:/Users/vikis/AppData/Local/Programs/Python/Python38/python.exe


def scan_map(player, p: Point, blocked: set, world: World):   
    
    explored = {}
    current = [p]
    
    closestHuman = None
    closestMyTombstone = None
    closestEnemyTombstone = None
    closestMyTombstoneDist = 0
    closestEnemyTombstoneDist = 0
    
    explored[p] = None
    
    while len(current) > 0:
        
        new_current = []
        for cur in current:
            
            neighbours = cur.get_neighbouring()
        
            for neighbour in neighbours:
                
                if neighbour in explored:
                    continue
                
                if neighbour in blocked:
                    continue
                
                if world.map.can_move_to(neighbour):
                    
                    new_current.append(neighbour)
                    explored[neighbour] = cur
                    
                    # nasli sme cloveka
                    if closestHuman == None and neighbour in player.peoplePositions:
                        player.log("found person")
                        
                        prev = neighbour
                        while explored[prev] != p:
                            prev = explored[prev]
                        
                        closestHuman = prev
                            
                    if closestMyTombstone == None and neighbour in player.myTombstones:
                        player.log("found my tombstone")
                        
                        closestMyTombstone = player.myTombstones[neighbour]
                        
                        prev = neighbour
                        while explored[prev] != p:
                            closestMyTombstoneDist += 1
                            prev = explored[prev]
                            
                    if closestEnemyTombstone == None and neighbour in player.enemyTombstones:
                        player.log("found enemy tombstone")
                        
                        closestEnemyTombstone = player.enemyTombstones[neighbour]
                        
                        prev = neighbour
                        while explored[prev] != p:
                            closestEnemyTombstoneDist += 1
                            prev = explored[prev]
                    
        current = new_current  
        
    return closestHuman, closestMyTombstone, closestMyTombstoneDist, closestEnemyTombstone, closestEnemyTombstoneDist
            
def move_to(player, start: Point, finish: Point, blocked: set):
    
    world = player.world
    
    explored = {}
    current = [start]
    
    explored[start] = None
    
    while len(current) > 0:
        
        new_current = []
        for cur in current:
            
            neighbours = cur.get_neighbouring()
        
            for neighbour in neighbours:
                
                if neighbour in explored:
                    continue
                
                if neighbour in blocked:
                    continue
                
                if world.map.can_move_to(neighbour):
                    
                    new_current.append(neighbour)
                    explored[neighbour] = cur
                    
                    # nasli sme cloveka
                    if neighbour == finish:
                        
                        player.log("found guy :)") 
                        
                        prev = neighbour
                        while explored[prev] != start:
                            prev = explored[prev]
                        
                        return prev
                    
        current = new_current  

def get_fear(player, p: Point) -> int:
    """
    Vrati pocet dusi z nepriatelskych timov vo vyhlade tejto duse.
    """
    
    shade_positions = player.shadePositions
    
    fear = 0
    for pos in p.get_visible():
        if pos in shade_positions and shade_positions[pos].owner != player.owner:
            fear += 1
    return fear

def get_enemy_fears(player, p: Point):
    shade_positions = player.shadePositions
    fears = {}
    for pos in p.get_visible():
        if pos in shade_positions and shade_positions[pos].owner != player.owner:
            fears[shade_positions[pos]] = shade_positions[pos].get_fear(shade_positions)
    return fears

def will_i_die(player, p: Point) -> bool:
    
    shade_positions = player.shadePositions
    
    enemy_fears = get_enemy_fears(player, p)
    mn_enemy_fear = min(enemy_fears.values()) if enemy_fears else math.inf
    return mn_enemy_fear <= get_fear(player, p)
    
    finalFear = 0
    finalHappiness = 999
    
    for x in (-1, 1):
        for y in (-1, 1):
            
            pos = Point(x + p.x, y + p.y)
            
            fear = 0
            happiness = 0
            
            for pos in pos.get_visible():
                if pos in shade_positions:
                    if shade_positions[pos].owner != player.owner:
                        fear += 1
                    else:
                        happiness += 1
                    
            finalFear = max(fear, finalFear)
            finalHappiness = min(happiness, finalHappiness)
            
    if finalHappiness >= finalFear:
        return False
    else:
        return True
        
def defense(player, blocked: set, shadeToClosestMyTombstone: dict[Tombstone, tuple]): 
    
    for base, shades in shadeToClosestMyTombstone.items():
        closest_shades = []
        for i in range(7):
            closest_shades.append(shades[i][1])
        i=0
        position = []
        for shade in closest_shades:
            if i==0:
                position = Point(base.x-1, base.y-1)
            if i==1:
                position = Point(base.x, base.y-1)
            if i==2:
                position = Point(base.x+1, base.y-1)
            if i==3:
                position = Point(base.x-1, base.y)
            if i==4:
                position = Point(base.x+1, base.y)
            if i==5:
                position = Point(base.x-1, base.y+1)
            if i==6:
                position = Point(base.x+1, base.y+1)
            if shade.x != position[0] or shade.y != position[1]:
                pos = move_to(player, shade.position, position, blocked)
                if pos != None:
                    player.moves.append(Move(shade.id, pos))
                    blocked.add(pos)
                
            player.alreadyMovedShades.append(shade)  
            i+=1
            
class Player(PlayerInterface):
    
    @staticmethod
    def log(*args):
        print(*args, file=sys.stderr)

    def init(self, world: World) -> None:
        Player.log("init")
        pass

    def get_turn(self, world: World) -> List[Move]:
        
        self.world = world
        self.myShades: set[Shade] = set()
        self.myTombstones: dict[Point, Tombstone] = {}
        self.enemyTombstones: set[Point, Tombstone] = {}
        self.peoplePositions: set[Point] = set()
        self.shadePositions: dict[Point, Shade] = world.alive_shades
        self.alreadyMovedShades = set()
        
        for person in world.alive_people:
            self.peoplePositions.add(person.position)
            
        
        self.moves = []
        blocked = set()
        
        # ziskam svoje shades
        for shade_id, shade in world.alive_shades.items():
            if shade.owner == world.my_id:
                self.myShades.add(shade)
                
        # ziskam moje tombstones
        for tombstone in world.alive_tombstones:
            if tombstone.owner == world.my_id:
                self.myTombstones[tombstone.position] = tombstone
            else:
                self.myTombstones[tombstone.position] = tombstone
                
        
        shadeToClosestMyTombstone = {}
        shadeToClosestEnemyTombstone = {}
        
        closestHumanToShade = {}
        
        for shade in self.myShades:
            closestHuman, closestMyTombstone, closestMyTombstoneDist, closestEnemyTombstone, closestEnemyTombstoneDist = scan_map(self, shade.position, blocked, world)
            
            if closestHuman != None:
                closestHumanToShade[shade] = closestHuman
                blocked.add(closestHuman)
            
            # priradim shade k ich najblizsim myTombstone
            if closestMyTombstone != None:
                if closestMyTombstone not in shadeToClosestMyTombstone:
                    shadeToClosestMyTombstone[closestMyTombstone] = []
                
                shadeToClosestMyTombstone[closestMyTombstone].append((closestMyTombstoneDist, shade))
                
            # priradim shade k ich najblizsim enemyTombstone
            if closestEnemyTombstone != None:
                if closestEnemyTombstone not in shadeToClosestEnemyTombstone:
                    shadeToClosestEnemyTombstone[closestEnemyTombstone]  = []
                    
                shadeToClosestEnemyTombstone[closestEnemyTombstone].append((closestEnemyTombstoneDist, shade))
                
                    
        for tombstone, shades in shadeToClosestMyTombstone.items():
            shadeToClosestMyTombstone[tombstone] = sorted(shades, key=lambda x: x[0])
            
        # defense
        if False:
            defense(self, blocked, shadeToClosestMyTombstone)
                
        for shade in self.myShades:
            if shade in self.alreadyMovedShades:
                continue
            
            if shade in closestHumanToShade:
                closestHuman = closestHumanToShade[shade]
                self.moves.append(Move(shade.id, closestHuman))
                blocked.add(closestHuman)
                self.alreadyMovedShades.add(shade)
             
        for shade in self.myShades:
            
            if shade not in self.alreadyMovedShades:
                continue
            
            if shade.position in blocked:
                
                self.log("is in blocked")
                
                skip = False
                
                for i in (-1, 1):
                    
                    if skip:
                        break
                    
                    for j in (-1, 1):
                        
                        p = Point(i + shade.position.x, j + shade.position.y)
                        
                        if p not in blocked:
                            
                            self.log("unblocked")
                            
                            self.moves.append(Move(shade.id, p))
                            blocked.add(p)
                            skip = True
                            break
                        
        for i, move1 in enumerate(self.moves):
            for j, move2 in enumerate(self.moves):
                if i == j:
                    continue
                if move1.target == move2.target:
                    self.log("duplicate")
    
        return self.moves

if __name__ == "__main__":
    game = Game(Player())
    game.run()